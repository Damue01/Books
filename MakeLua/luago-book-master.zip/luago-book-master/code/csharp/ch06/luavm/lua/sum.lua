local sum = 0
for i = 1, 100 do
    if i % 2 == 0 then
        sum = sum + i
    end
end
