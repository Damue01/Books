package main

func main() {
	println("Hello, World!")
}
